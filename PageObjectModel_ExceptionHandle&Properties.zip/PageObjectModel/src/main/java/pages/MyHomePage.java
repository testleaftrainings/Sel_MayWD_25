package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecficMethod;

public class MyHomePage extends ProjectSpecficMethod{

//	public MyHomePage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	public MyLeadsPage clickOnLeads() {
		getDriver().findElement(By.linkText(pop.getProperty("MyHomePage.Leads"))).click();
		return new MyLeadsPage();
	}
	
	public MyAccountsPage clickOnAccounts() {
		getDriver().findElement(By.linkText("Accounts")).click();
		return new MyAccountsPage();
	}
	
	public void clickOnCases() {
		getDriver().findElement(By.linkText("Cases")).click();
	}
}
