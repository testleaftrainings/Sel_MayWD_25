package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecficMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecficMethod{

//	public LoginPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	
	@When("Enter the username as {string}")
	public LoginPage enterUserName() {
		try {
			getDriver().findElement(By.id("username")).sendKeys(pop.getProperty("username"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return this;
	}
	
	@And("Enter the Password as {string}")
	public LoginPage enterPassword() {
		getDriver().findElement(By.id("password")).sendKeys(pop.getProperty("password"));
		return this;
}
	@And("Click on LoginButton")
	public HomePage clickOnLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
        return new HomePage();
	}
}
