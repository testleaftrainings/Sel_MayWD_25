package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecficMethod;

public class MyLeadsPage extends ProjectSpecficMethod{
	
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	public MyLeadsPage clickOnCreateLead() {
		getDriver().findElement(By.linkText(pop.getProperty("MyLeadsPage.CreateLead"))).click();	
		return this;
	}
	
	public MyLeadsPage clickOnFindLeads() {
		getDriver().findElement(By.linkText("Find Leads")).click();
		return this;
	}

}
