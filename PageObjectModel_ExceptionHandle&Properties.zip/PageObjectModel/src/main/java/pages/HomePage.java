package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecficMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecficMethod{
	
//public HomePage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	@And("Click on crmsfa")
	public MyHomePage clickOnCRMSFA() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
        return new MyHomePage();
	}
	
	public LoginPage clickOnLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
        return new LoginPage();    
	}
	
	
	@Then("Verify Login is Successful")
	public void verifyPage() {
		String title = getDriver().getTitle();
		if(title.contains("My Home")) {
			System.out.println("Login is Successful");
		}else {
			System.out.println("Login is not Successful");
		}
		
	}
	

}
