package pages;

import org.openqa.selenium.By;

import base.ProjectSpecficMethod;

public class MyAccountsPage extends ProjectSpecficMethod{
	
	public MyAccountsPage clickOnCreateAccount() {
		getDriver().findElement(By.linkText("Create Account")).click();
		return this;
	}

}
