package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecficMethod;
import pages.LoginPage;

public class TC_002_CreateLead extends ProjectSpecficMethod {

//	@BeforeTest
//	public void getdata() {
//		fileName="CreateLead";
//	}
	
	
	@Test
	public void clickCreateLead() {
		LoginPage lp=new LoginPage();
		System.out.println(getDriver());
		lp.enterUserName()
		.enterPassword()
		.clickOnLogin()
		.clickOnCRMSFA()
		.clickOnLeads()
		.clickOnCreateLead();
		
	}
}
