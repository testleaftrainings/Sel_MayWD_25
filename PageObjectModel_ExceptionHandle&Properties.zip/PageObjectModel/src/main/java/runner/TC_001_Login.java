package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecficMethod;
import pages.LoginPage;

public class TC_001_Login extends ProjectSpecficMethod{

	@BeforeTest
	public void getData() {
		fileName="Login1";
	}
	
	
	
	@Test(dataProvider = "getValue")
	public void login(String uN,String pass) {
		LoginPage lp=new LoginPage();
		System.out.println(getDriver());
		lp.enterUserName()
		.enterPassword()
		.clickOnLogin()
		.clickOnCRMSFA();
		
	}
	
}
