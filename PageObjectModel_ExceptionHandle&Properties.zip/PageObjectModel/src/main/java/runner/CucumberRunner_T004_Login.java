package runner;

import base.ProjectSpecficMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features/Login.feature",
glue="pages",publish=true)



public class CucumberRunner_T004_Login extends ProjectSpecficMethod{

}
