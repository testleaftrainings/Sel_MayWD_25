package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadValueFromPropertyFile {

	public static void main(String[] args) throws IOException {

		FileInputStream file=new FileInputStream("src/main/resources/French.properties");
		
		Properties pop=new Properties();
		
		//load() -> will connect fis and prp
		pop.load(file);
		
		String property = pop.getProperty("MyHomePage.Leads");
		System.out.println(property);
	}

}
