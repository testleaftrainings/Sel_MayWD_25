package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ExcelSheet;

public class ProjectSpecficMethod extends AbstractTestNGCucumberTests{

	//step1
	private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();


	//step 2 -> create setter and getter method to access private variable
	public void setDriver() {
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("guest");
		tlDriver.set(new ChromeDriver(opt));
	}

	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}


	public String fileName;
	public static Properties pop;
	
	@BeforeMethod
	public void preCondition() throws IOException {

		FileInputStream file=new FileInputStream("src/main/resources/English.properties");

		pop=new Properties();
		
		pop.load(file);

		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	}
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	//indices - index value start from'0'
	//read row value -from excel sheet
	@DataProvider(name="getValue" ,indices = {1} )
	public String[][] setValue() throws IOException {
		return ExcelSheet.readExcel(fileName);
	}


}
