package base;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnExceptionHandling {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.facebook.com/");
		try {
			driver.findElement(By.id("emai")).sendKeys("dilip@testleaf.com");
		} catch (Exception e) {
			System.out.println(e);
			driver.findElement(By.name("email")).sendKeys("dilipdk@gmail.com");
		}finally {
			System.out.println("check the email address updated");
		}
		
		Thread.sleep(3000);
		
		driver.findElement(By.id("pass")).sendKeys("test@123");
		driver.findElement(By.name("login")).click();

		throw new NoSuchElementException("Kindly check data is correct");

		
		
		//compile time exceptions - throw and throws
		//throw-> keyword -> user define -> own exception
		//throws -> keyword-> system define -> predefined exception
		
	}

	
	
	
}
