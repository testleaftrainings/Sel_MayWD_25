package week5.day1;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static String[][] readData(String filename) throws IOException {
		// To open the workbook
		XSSFWorkbook wb = new XSSFWorkbook("./Data/" + filename + ".xlsx");

		// To open a worksheet -getSheet
		XSSFSheet ws = wb.getSheet("Sheet1");

		// To count the number of rows - without header
		int rowCount = ws.getLastRowNum();
		System.out.println("The row is: " + rowCount);

		// To count the number of rows - with header
		int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
		System.out.println("Row count with header: " + physicalNumberOfRows);

		// To count the number of columns
		int columnCount = ws.getRow(1).getLastCellNum();
		System.out.println("The column count is: " + columnCount);

		// To retrieve a data
		String row1Cell1Data = ws.getRow(1).getCell(1).getStringCellValue();
		System.out.println("The data is: " + row1Cell1Data);

		String[][] data = new String[rowCount][columnCount];

		// To retrieve the entire data
		for (int i = 1; i <= rowCount; i++) {

			XSSFRow row = ws.getRow(i);

			for (int j = 0; j < columnCount; j++) {
				String allData = row.getCell(j).getStringCellValue();
				data[i - 1][j] = allData;
				System.out.println("The all data is: " + allData);
			}
		}

		wb.close();
		return data;

	}

}
