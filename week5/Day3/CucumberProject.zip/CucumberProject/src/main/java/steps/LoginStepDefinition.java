package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition {
	public EdgeDriver driver;
	
	@Given("Launch the Browser")
	public void launchBrowser() {
		driver=new EdgeDriver();
		driver.manage().window().maximize();

	}

	@And("Load the url")
	public void load_the_url() {
	    driver.get("http://leaftaps.com/opentaps");
	}

	@And("Enter the username as Demosalesmanager")
	public void enter_the_username_as_demosalesmanager() {
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
	}

	@And("Enter the password as crmsfa")
	public void enter_the_password_as_crmsfa() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}

	@When("Clcik on the login button")
	public void clcik_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should navigate to the next page")
	public void it_should_navigate_to_the_next_page() {
	    System.out.println("Login was successful");
	}

}
