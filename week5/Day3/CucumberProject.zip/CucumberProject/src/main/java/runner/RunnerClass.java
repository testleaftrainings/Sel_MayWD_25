package runner;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/feature/Login.feature", glue = "steps")
public class RunnerClass extends AbstractTestNGCucumberTests {

}
